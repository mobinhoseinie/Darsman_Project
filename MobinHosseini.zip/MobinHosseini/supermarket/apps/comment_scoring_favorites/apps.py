from django.apps import AppConfig


class CommentScoringFavoritesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.comment_scoring_favorites'
