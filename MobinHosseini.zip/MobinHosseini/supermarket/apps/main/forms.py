from django import forms
from .models import ContactMessage


class ContactMessageForm(forms.ModelForm):
    
    class Meta:
        model = ContactMessage
        fields = ("name", "email", "title", "text")
        widgets = {
            'name': forms.TextInput(attrs={'class':'form-control','placeholder':'نام را وارد کنید',}),
            'email': forms.EmailInput(attrs={'class':'form-control','placeholder':'ایمیل را وارد کنید','dir':'ltr',}),
            'title': forms.TextInput(attrs={'class':'form-control','placeholder':'عنوان را وارد کنید',}),
            'text': forms.Textarea(attrs={'class':'form-control','placeholder':'متن پیام را وارد کنید','rows':'4',}),
        }
