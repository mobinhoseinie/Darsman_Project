from django.shortcuts import render,redirect
from django.conf import settings
from django.views import View
from .forms import ContactMessageForm
from django.contrib import messages
from django.db.models import Q
from .models import Slider


def media_admin(request):
    return {'media_url':settings.MEDIA_URL}


def index(request):
    return render(request, "main_app/index.html")

def about_us(request):
    return render(request, "main_app/about_us.html")

class ContactMessage(View):
    def get(self, request):
        if request.user.is_authenticated:
            inital_data = {
                'name' : f'{request.user.name}{request.user.family}',
                'email': f'{request.user.email}'
            }
            form = ContactMessageForm(initial=inital_data)
        else:
            form = ContactMessageForm()
        return render(request, "main_app/contact_us.html", {'form':form})
    
    def post(self, request):
        form = ContactMessageForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "پیام شما با موفقیت ارسال شد", 'success')
            return redirect("main:index")
        else:
            messages.error(request, "اطلاعات وارد شده معتبر نیست", 'danger')
            return redirect("main:contact_us")


# Slider ==========================================================================================
class SliderView(View):
    def get(self, request):
        sliders = Slider.objects.filter(is_active=True)
        return render(request, "main_app/sliders.html", {'sliders':sliders})
