from django.db import models
from django.utils import timezone
from django.utils.html import mark_safe
from uuid import uuid4
import os


# Contact -----------------------------------------------------------------------------------------
class ContactMessage(models.Model):
    title = models.CharField(max_length=50, verbose_name='عنوان پیام')
    text = models.TextField(verbose_name='متن پیام')
    name = models.CharField(max_length=100, verbose_name='نام ارسال‌کننده')
    email = models.EmailField(max_length=254, verbose_name='ایمیل')
    date = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ارسال پیام')
    is_seen = models.BooleanField(default=False, verbose_name='وضعیت مشاهده')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'پیام'
        verbose_name_plural = 'پیام‌ها'



# Slider ------------------------------------------------------------------------------------------
def slider_image_path(instance, filename):
    filename, ext = os.path.splitext(filename)
    return f'images/slider_pic/{uuid4()}{ext}'
#-------
class Slider(models.Model):
    slider_title1 = models.CharField(max_length=500, null=True, blank=True, verbose_name='متن اول')
    slider_title2 = models.CharField(max_length=500, null=True, blank=True, verbose_name='متن دوم')
    slider_title3 = models.CharField(max_length=500, null=True, blank=True, verbose_name='متن سوم')

    image_name = models.ImageField(upload_to=slider_image_path, verbose_name='تصویر اسلاید')

    slider_link = models.URLField(max_length=200, null=True, blank=True, verbose_name='لینک')
    is_active = models.BooleanField(default=True, blank=True, verbose_name='وضعیت فعال/غیرفعال')
    register_date = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ درج')
    published_date = models.DateTimeField(default=timezone.now, verbose_name='تاریخ انتشار')
    update_date = models.DateTimeField(auto_now=True, verbose_name='تاریخ آخرین بروزرسانی')
    
    def __str__(self):
        return f"{self.slider_title1}"

    class Meta:
        verbose_name = 'اسلاید'
        verbose_name_plural = 'اسلایدها'
    
    def image_slide(self):
        return mark_safe(f'<img src="/media/{self.image_name}/" style="width:80px;height:80px"/>')
    image_slide.short_description = 'تصویر اسلاید'

    def link(self):
        return mark_safe(f'<a href="{self.slider_link}" target="_blank">link</a>')
    link.short_description = 'پیوندها'