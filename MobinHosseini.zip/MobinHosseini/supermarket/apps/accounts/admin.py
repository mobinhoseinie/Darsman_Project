from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User
from .forms import UserCreationForm,UserChangeForm

class UserAdmin(UserAdmin):

    form = UserChangeForm
    add_form = UserCreationForm

    list_display = ("mobile_number", "full_name", "email", "register_date", "is_active", "is_admin")
    list_filter = ('is_admin', 'is_active')
    ordering = ('register_date',)
    readonly_fields = ('register_date',)

    def full_name(self, obj):
        return f"{obj.name} {obj.family}"
    full_name.short_description = "نام و نام‌خانوادگی"


    fieldsets = (
        (None, {
            "fields": (
                ("mobile_number","password"),
                ("name", "family"),
                "email",
                "address",
                ("is_active", "is_admin", 'is_superuser'),
                'groups',
                'user_permissions',
                "image",
            ),
        }),
    )

    add_fieldsets = (
        (None, {
            "fields": (
                "mobile_number",
                ("password1","password2"),
                ("name", "family"),
                "email",
                "address",
                ("is_active", "is_admin", 'is_superuser'),
                'groups',
                'user_permissions',
                "image",
            ),
        }),
    )
    
    filter_horizontal = ("groups", "user_permissions")
    
admin.site.register(User, UserAdmin)