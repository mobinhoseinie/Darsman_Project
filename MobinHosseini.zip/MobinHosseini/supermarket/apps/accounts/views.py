from django.shortcuts import render,redirect
from django.views import View
from .forms import (SignUpForm,LoginForm,VerifyForm,
                    PasswordResetRequestForm,PasswordResetVerifyForm,
                    PasswordResetSetForm,UserEditProfileForm,
                    UserChangePasswordForm,)
from .models import User
from django.contrib import messages
import utils
from django.contrib.auth import login,logout,authenticate,update_session_auth_hash
from django.contrib.auth.mixins import LoginRequiredMixin



# Sign-UP -----------------------------------------------------------------------------------------
class SignUpView(View):
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("main:index")
        return super().dispatch(request, *args, **kwargs)
    
    def get(self, request):
        form = SignUpForm()
        return render(request, "accounts_app/signup.html", {'form':form})
    
    def post(self, request):
        form = SignUpForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            user = User.objects.create_user(
                mobile_number = data['mobile_number'],
                password = data['password1']
            )
            request.session['user_session'] = {
                'mobile_number' : data['mobile_number'],
            }
            print(100*'-')
            print(user.active_code)
            print(100*'-')
            messages.success(request, "لطفا کد دریافتی را وارد کنید", 'success')
            return redirect('accounts:verify')
        else:
            messages.error(request, "اطلاعات وارد شده معتبر نمی‌باشد", 'danger')
            return render(request, "accounts_app/signup.html", {'form':form})


# Login -----------------------------------------------------------------------------------------
class LoginView(View):
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("main:index")
        return super().dispatch(request, *args, **kwargs)
    
    def get(self, request):
        form = LoginForm()
        return render(request, "accounts_app/login.html", {'form':form})
    
    def post(self, request):
        form = LoginForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            user = authenticate(username=data['mobile_number'],password=data['password'])
            if user is not None :
                try:
                    db_user = User.objects.get(mobile_number=data['mobile_number'])
                except User.DoesNotExist:
                    messages.error(request, "چنین شماره‌ای ثبت نشده", 'danger')
                    return render(request, "accounts_app/login.html", {'form':form})
                if not db_user.is_active:
                    messages.error(request, "حساب شما فعال نشده است", 'danger')
                    return render(request, "accounts_app/login.html", {'form':form})
                login(request, user)
                messages.success(request, 'خوش آمدید', "success")
                next_url = request.GET.get('next', 'main:index')
                return redirect(next_url)
            else :
                messages.error(request, "نام کاربری یا رمز اشتباه است", 'danger')
                return render(request, "accounts_app/login.html", {'form':form})

        else:
            messages.error(request, 'اطلاعات نا معتبر', 'danger')
            return render(request, "accounts_app/login.html", {'form':form})

    
# LogOut ------------------------------------------------------------------------------------------
class LogoutView(LoginRequiredMixin,View):
    login_url = 'accounts:login'
    def get(self, request):
        session_data = request.session.get('shop_cart')
        logout(request)
        request.session['shop_cart'] = session_data
        messages.success(request, "با موفقیت از حساب کاربری خارج شدید", "success")
        return redirect("main:index")
    
    

# Verify ------------------------------------------------------------------------------------------
class VerifyView(View):
    def get(self, request):
        form = VerifyForm()
        return render(request, "accounts_app/verify.html", {'form':form})
    
    def post(self, request):
        form = VerifyForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            code = data['verify_code']  
            try:
                user = User.objects.get(mobile_number=request.session['user_session']['mobile_number'])
            except User.DoesNotExist:
                messages.error(request, "کاربری با این شماره موبایل یافت نشد", "danger")
                return redirect("accounts:signup")
            if code == user.active_code:
                user.is_active = True
                user.active_code = utils.create_random_code(6)
                user.save()
                login(request, user)
                messages.success(request, 'ثبت‌نام با موفقیت انجام شد', 'success')
                return redirect('main:index')
            else:
                messages.error(request, "کد فعال سازی وارد شده اشتباه می باشد", "danger")
                return render(request, "accounts_app/verify.html", {'form':form})
        else:
            messages.error(request, "اطلاعات وارد شده معتبر نمی باشد", "danger")
            return render(request, "accounts_app/verify.html", {'form':form})


# REMEMBER PASSWORD ===============================================================================
# Request for Remember-Password -------------------------------------------------------------------
class PasswordResetRequestView(View):
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("main:index")
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        form = PasswordResetRequestForm()
        return render(request, 'accounts_app/password_reset_request.html', {'form': form})
    
    def post(self, request):
        form = PasswordResetRequestForm(request.POST)
        if form.is_valid():
            mobile = form.cleaned_data['mobile_number']
            try:
                user = User.objects.get(mobile_number=mobile)
            except User.DoesNotExist:
                messages.error(request, "موبایل مورد نظر یافت نشد", 'danger')
                return render(request, 'accounts_app/password_reset_request.html', {'form': form})
            
            new_code = utils.create_random_code(6)
            user.active_code = new_code
            user.save()
            print(100*'=')
            print(new_code)
            print(100*'=')
            request.session['user_session'] = {
                'mobile_number' : mobile,
            }
            
            messages.success(request, "کد با موفقیت ارسال شد", 'success')
            return redirect('accounts:password_reset_verify')
        else:
            messages.error(request, 'اطلاعات وارد شده معتبر نیست', "danger")
            return render(request, 'accounts_app/password_reset_request.html', {'form': form})
        
# Verify ------------------------------------------------------------------------------------------
class PasswordResetVerifyView(View):
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect("main:index")
        return super().dispatch(request, *args, **kwargs)

    def get(self, request):
        form = PasswordResetVerifyForm()
        return render(request, "accounts_app/password_reset_verify.html", {'form':form})
    
    def post(self, request):
        form = PasswordResetVerifyForm(request.POST)
        if form.is_valid():
            code = form.cleaned_data['verify_code']
            try:
                user = User.objects.get(mobile_number = request.session['user_session']['mobile_number'])
            except User.DoesNotExist:
                messages.error(request, "چنین رکوردی یافت نشد", "danger")
                return render(request, "accounts_app/password_reset_verify.html", {'form':form})
            
            if code == user.active_code:
                return redirect('accounts:password_reset_set')
            else:
                messages.error(request, "کد وارد شده اشتباه است", "danger")
                return render(request, "accounts_app/password_reset_verify.html", {'form':form})
        else:
            messages.error(request, "فرم نامعتبر است", "danger")
            return render(request, "accounts_app/password_reset_verify.html", {'form':form})

# Set New Password --------------------------------------------------------------------------------
class PasswordResetSetView(View):
    def get(self, request):
        form = PasswordResetSetForm()
        return render(request, "accounts_app/password_reset_set.html", {'form':form})
    
    def post(self, request):
        form = PasswordResetSetForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            new_password = data['new_password1']
            try:
                user = User.objects.get(mobile_number = request.session['user_session']['mobile_number'])
            except User.DoesNotExist:
                messages.error(request, "چنین رکوردی یافت نشد", "danger")
                return render(request, "accounts_app/password_reset_set.html", {'form':form})
            user.set_password(new_password)
            user.active_code = utils.create_random_code(6)
            user.save()
            request.session.pop('user_session', None)
            messages.success(request, 'رمز عبور با موفقیت تغییر یافت.', 'success')
            return redirect('main:index')
        else:
            messages.error(request, "فرم نامعتبر است", "danger")
            return render(request, "accounts_app/password_reset_set.html", {'form':form})


# User Panel ======================================================================================
# Dashboard ---------------------------------------------------------------------------------------
class PanelView(LoginRequiredMixin,View):
    def get(self, request):
        user = request.user
        context = {
            'user' : user,
        }
        return render(request, "accounts_app/panel/panel.html", context)

# Edit Profile ------------------------------------------------------------------------------------
class EditProfileView(LoginRequiredMixin, View):
    def get(self, request):
        form = UserEditProfileForm(instance=request.user)
        return render(request, "accounts_app/panel/edit_profile.html", {'form': form})

    def post(self, request):
        form = UserEditProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'ویرایش پروفایل با موفقیت انجام شد', 'success')
            return redirect('accounts:panel')
        else:
            messages.error(request, 'اطلاعات نامعتبر است', 'danger')
        return render(request, "accounts_app/panel/edit_profile.html", {'form': form})
    
# Panel Change Password ---------------------------------------------------------------------------
class UserChangePasswordView(LoginRequiredMixin,View):
    def get(self, request):
        form = UserChangePasswordForm()
        return render(request, "accounts_app/panel/change_password.html", {'form':form})
    
    def post(self, request):
        form = UserChangePasswordForm(request.POST)
        if form.is_valid():
            data = form.cleaned_data
            if request.user.check_password(data['old_password']):
                request.user.set_password(data['new_password1'])
                request.user.save()
                update_session_auth_hash(request, request.user)
                messages.success(request, 'رمزعبور با موفقیت تغییر یافت', 'success')
                return redirect('accounts:panel')
            else:
                messages.error(request, 'رمزعبور کنونی اشتباه وارد شده', 'danger')
                return render(request, "accounts_app/panel/change_password.html", {'form':form})
        else:
            messages.error(request, 'فرم نامعتبر است', 'danger')
            return render(request, "accounts_app/panel/change_password.html", {'form':form})

            