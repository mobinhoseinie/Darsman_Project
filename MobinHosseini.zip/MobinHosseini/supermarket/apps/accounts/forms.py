from django import forms
from django.contrib.auth.forms import ReadOnlyPasswordHashField,AuthenticationForm
from .models import User
from django.core.exceptions import ValidationError

class UserCreationForm(forms.ModelForm):
    password1 = forms.CharField(
        label='رمزعبور',
        widget=forms.PasswordInput()
    )
    password2 = forms.CharField(
        label='تکرار رمزعبور',
        widget=forms.PasswordInput()
    )
    
    class Meta:
        model = User
        fields = ("mobile_number", "name", "family", "email", "address", "image")
    
    def clean_password2(self):
        pass1 = self.cleaned_data.get('password1')
        pass2 = self.cleaned_data.get('password2')
        if pass1 and pass2 and pass1 != pass2:
            raise ValidationError("رمز عبور و تکرار آن با هم مغایرت دارند")
        return pass2
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        if commit:
            user.save()
        return user


class UserChangeForm(forms.ModelForm):
    password = ReadOnlyPasswordHashField(label="رمز عبور")
    class Meta:
        model = User
        fields = ("mobile_number", "name", "family", "email", "address", "image", "is_active", "is_admin", "password")


# -----------------------------------------------------------------------------------
class SignUpForm(forms.ModelForm):

    password1 = forms.CharField(
        label='رمزعبور',
        widget=forms.PasswordInput(attrs={
            'class':'form-control',
            'placeholder':'رمزعبور را وارد کنید',
        }),
    )
    password2 = forms.CharField(
        label='تکرار رمزعبور',
        widget=forms.PasswordInput(attrs={
            'class':'form-control',
            'placeholder':'رمزعبور را تکرار کنید',
        }),
    )
    
    class Meta:
        model = User
        fields = ("mobile_number",)
        widgets = {
            'mobile_number' : forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'شماره موبایل را وارد کنید',
            }),
        }
    
    
    def clean_password2(self):
        pass1 = self.cleaned_data.get('password1')
        pass2 = self.cleaned_data.get('password2')
        if pass1 and pass2 and pass1 != pass2:
            raise ValidationError("رمز عبور و تکرار آن با هم مغایرت دارند")
        return pass2
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        if commit:
            user.save()
        return user
    

# LOGIN -------------------------------------------------------------------------------------------
class LoginForm(forms.Form):
    mobile_number = forms.CharField(
        label='شماره موبایل',
        required=True,
        error_messages={
            'required':'این فیلد نمیتواند خالی باشد',
        },
        widget=forms.TextInput(attrs={'class':'form-control','placeholder':'شماره موبایل را وارد کنید'},)
        )
    
    password = forms.CharField(
        label='رمز عبور',
        required=True,
        error_messages={
            'required':'این فیلد نمیتواند خالی باشد',
        },
        widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'رمزعبور را وارد کنید'},)
    )


# Verify FORM -------------------------------------------------------------------------------------
class VerifyForm(forms.Form):

    verify_code = forms.CharField(
        label='کد فعال‌سازی',
        required=True,
        error_messages={
            'required':'این فیلد نمی‌تواند خالی باشد',
        },
        widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'کد فعال‌سازی دریافتی را وارد کنید'},)
    )

    def clean_verify_code(self):
        code = self.cleaned_data.get('verify_code')
        if not code.isdigit():
            raise ValidationError("کد باید فقط شامل رقم باشد")
        return code

# Request for Remember-Password -------------------------------------------------------------------
class PasswordResetRequestForm(forms.Form):
    mobile_number = forms.CharField(
        label='شماره موبایل',
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'شماره موبایل را وارد کنید',
        })
    )
    def clean_mobile_number(self):
        mobile = self.cleaned_data.get('mobile_number').strip()
        if not mobile.isdigit():
            raise ValidationError('شماره موبایل معتبر نیست.')
        return mobile


# Password Reset Verify ---------------------------------------------------------------------------
class PasswordResetVerifyForm(forms.Form):
    verify_code = forms.CharField(
        label='کد بازیابی',
        required=True,
        error_messages={
            'required': 'این فیلد نمی‌تواند خالی باشد',
        },
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'کد ارسال شده را وارد کنید',
        })
    )

    def clean_verify_code(self):
        code = self.cleaned_data.get('verify_code').strip()
        if not code.isdigit():
            raise ValidationError('کد باید فقط شامل اعداد باشد.')
        return code


# Password Reset SET ------------------------------------------------------------------------------
class PasswordResetSetForm(forms.Form):
    new_password1 = forms.CharField(
        label='رمز عبور جدید',
        required=True,
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'رمز عبور جدید را وارد کنید',
        }),
        error_messages={'required': 'این فیلد نمی‌تواند خالی باشد'},
    )

    new_password2 = forms.CharField(
        label='تکرار رمز عبور جدید',
        required=True,
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'رمز عبور جدید را دوباره وارد کنید',
        }),
        error_messages={'required': 'این فیلد نمی‌تواند خالی باشد'},
    )

    def clean_new_password2(self):
        pass1 = self.cleaned_data.get('new_password1')
        pass2 = self.cleaned_data.get('new_password2')
        if pass1 and pass2 and pass1 != pass2:
            raise ValidationError('رمز عبور و تکرار آن یکسان نیستند.')
        return pass2





# Panel FORMS =====================================================================================
# Panel Edit Profile FORM -------------------------------------------------------------------------
class UserEditProfileForm(forms.ModelForm):
    
    class Meta:
        model = User
        fields = ("name", "family", "email", "address", "image")
        widgets = {
            'name' : forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'نام خود را وارد کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
            }),
            'family' : forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'نام خانوادگی خود را وارد کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
            }),
            'email' : forms.EmailInput(attrs={
                'class':'form-control',
                'placeholder':'ایمیل خود را وارد کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
            }),
            'address' : forms.Textarea(attrs={
                'class':'form-control',
                'placeholder':'آدرس خود را وارد کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
                'rows':'4',
            }),
        }

# Panel Change Password FORM ----------------------------------------------------------------------
class UserChangePasswordForm(forms.Form):
    old_password = forms.CharField(
        label='رمز عبور قدیمی',
        required=True,
        widget=forms.PasswordInput(
            attrs={
                'class' : 'form-control',
                'placeholder':'رمزعبور کنونی خود را وارد کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
            },
        ),
    )
    new_password1 = forms.CharField(
        label='رمز عبور جدید',
        required=True,
        widget=forms.PasswordInput(
            attrs={
                'class' : 'form-control',
                'placeholder':'رمزعبور جدید را وارد کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
            },
        ),
    )
    new_password2 = forms.CharField(
        label='تکرار رمزعبور جدید',
        required=True,
        widget=forms.PasswordInput(
            attrs={
                'class' : 'form-control',
                'placeholder':'رمزعبور جدید را تکرار کنید',
                'required':'این فیلد نمی‌تواند خالی بماند',
            },
        ),
    )
    def clean_new_password2(self):
        pass1 = self.cleaned_data.get('new_password1')
        pass2 = self.cleaned_data.get('new_password2')
        if pass1 and pass2 and pass1 != pass2:
            raise ValidationError('رمز عبور و تکرار آن یکسان نیستند.')
        return pass2
    
    


