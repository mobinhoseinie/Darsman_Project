from django.db import models
from django.contrib.auth.models import AbstractBaseUser,PermissionsMixin,BaseUserManager
import os
from uuid import uuid4
import utils

def image_path(instance, filename):
    filename, ext = os.path.splitext(filename)
    return f'images/users_pic/{instance.mobile_number}/{uuid4()}{ext}'

# User Manager ------------------------------------------------------------------------------------
class UserManager(BaseUserManager):
    def create_user(self, mobile_number, password=None, name="", family="", email="", address=""):
        if not mobile_number:
            raise ValueError("شماره موبایل باید وارد شود")
        user = self.model(
            mobile_number = mobile_number,
            name = name,
            family = family,
            email = self.normalize_email(email),
            address = address,
            active_code = utils.create_random_code(6),
        )
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, mobile_number, password, name, family, email):
        user = self.create_user(
            mobile_number = mobile_number,
            password = password,
            name = name,
            family = family,
            email = email,
        )
        user.is_active = True
        user.is_admin = True
        user.is_superuser = True
        user.save(using=self._db)
        return user

# USER --------------------------------------------------------------------------------------------
class User(AbstractBaseUser,PermissionsMixin):
    mobile_number = models.CharField(max_length=11, unique=True, null=False, blank=False, verbose_name='شماره موبایل')
    name = models.CharField(max_length=50, null=False, blank=True, verbose_name='نام')
    family = models.CharField(max_length=50, null=False, blank=True, verbose_name='نام‌خانوادگی')
    email = models.EmailField(max_length=254, blank=True, null=False, verbose_name='ایمیل')
    address = models.TextField(null=False, blank=True, verbose_name='آدرس')
    image = models.ImageField(upload_to=image_path, blank=True, null=True, verbose_name='تصویر کاربر')
    register_date = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ثبت‌نام')
    active_code = models.CharField(max_length=50, verbose_name='کد فعال‌سازی')
    is_active = models.BooleanField(default=False, verbose_name='وضعیت فعال/غیرفعال')
    is_admin = models.BooleanField(default=False)

    USERNAME_FIELD = 'mobile_number'
    REQUIRED_FIELDS = ['email', 'name', 'family',]

    objects = UserManager()

    @property
    def is_staff(self):
        return self.is_admin

    class Meta:
        verbose_name = 'کاربر'
        verbose_name_plural = 'کاربران'

    def __str__(self):
        return f"{self.name} {self.family} - {self.mobile_number}"
