from django.shortcuts import render
from django.views import View
from django.db.models import Q,Count
from apps.products.models import Product,Product_Group
from django.contrib import messages

class SearchResultsView(View):
    def get(self, request):
        all_groups = Product_Group.objects.filter(Q(is_active=True) & ~Q(group_parent = None)).annotate(count=Count('products_of_groups')).order_by('-count')
        query = request.GET.get("q", "").strip()
        products = Product.objects.filter(
            is_active = True,
            name__icontains = query
        )

        context = {
            'products':products,
            'query':query,
            'all_groups':all_groups,
        }

        if not query:
            messages.warning(request, "لطفاً عبارتی برای جستجو وارد کنید.")
            return render(request, "search_app/search_results.html", {
                "products": [],
                "query": query,
            })
        

        return render(request, "search_app/search_results.html", context)

