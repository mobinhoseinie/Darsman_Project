from django.contrib import admin
from .models import Coupon,DiscountBasket,DiscountBasketDetails

# Coupon ADMIN --------------------------------------------------------------------------------------------------------
@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ('coupon_code', 'start_date', 'end_date', 'discount', 'is_active')
    ordering = ('is_active',)


# Discount Basket Details INLINE --------------------------------------------------------------------------------------
class DiscountBasketDetailsInline(admin.TabularInline):
    model = DiscountBasketDetails
    extra = 3


# Discount Basket ADMIN -----------------------------------------------------------------------------------------------
@admin.register(DiscountBasket)
class DiscountBasketAdmin(admin.ModelAdmin):
    list_display = ('discount_title', 'start_date', 'end_date', 'discount', 'is_active')
    ordering = ('is_active',)
    inlines = [DiscountBasketDetailsInline]
