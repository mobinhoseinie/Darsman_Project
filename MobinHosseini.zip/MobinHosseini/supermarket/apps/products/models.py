from django.db import models
import os
from uuid import uuid4
from django.utils import timezone
from django.urls import reverse
from django.db.models import Sum,Avg
from middlewares.middlewares import RequestMiddleware
from datetime import datetime

# Brand -------------------------------------------------------------------------------------------
def brand_image_path(instance, filename):
    filename, ext = os.path.splitext(filename)
    return f'images/brand_pic/{instance.slug}/{uuid4()}{ext}'
class Brand(models.Model):
    title = models.CharField(max_length=50, verbose_name='نام برند')
    slug = models.SlugField(unique=True)
    image = models.ImageField(upload_to=brand_image_path, verbose_name='تصویر برند', null=True, blank=True)
    
    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'برند'
        verbose_name_plural = 'برندها'


# Product GROUP -----------------------------------------------------------------------------------
def product_group_image_path(instance, filename):
    filename, ext = os.path.splitext(filename)
    return f'images/product_group_pic/{instance.title}/{uuid4()}{ext}'
class Product_Group(models.Model):
    title = models.CharField(max_length=50, verbose_name='عنوان گروه کالا', unique=True)
    image = models.ImageField(upload_to=product_group_image_path, null=True, blank=True, verbose_name='تصویر کالا')
    description = models.TextField(blank=True, null=True, verbose_name='توضیحات گروه کالا')
    is_active = models.BooleanField(default=True, blank=True, verbose_name='وضعیت فعال/غیرفعال')
    group_parent = models.ForeignKey('Product_Group', on_delete=models.CASCADE, verbose_name='والد گروه کالا', blank=True, null=True, related_name='groups')
    register_date = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ درج')
    publish_date = models.DateTimeField(default=timezone.now, verbose_name='تاریخ انتشار')
    update_date = models.DateTimeField(auto_now=True, verbose_name='تاریخ آخرین بروزرسانی')
    slug = models.SlugField(max_length=200, null=True)
    
    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'گروه کالا'
        verbose_name_plural = 'گروه‌های کالا'


# Feature -----------------------------------------------------------------------------------------
class Feature(models.Model):
    title = models.CharField(max_length=50, verbose_name='عنوان ویژگی')
    
    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'ویژگی'
        verbose_name_plural = 'ویژگی‌ها'


# Product -----------------------------------------------------------------------------------------
def product_image_path(instance, filename):
    filename, ext = os.path.splitext(filename)
    return f'images/product_pic/{instance.slug}/{uuid4()}{ext}'
class Product(models.Model):
    name = models.CharField(max_length=50, verbose_name='نام کالا')
    summery_description = models.TextField(null=True, blank=True, verbose_name='خلاصه توضیحات')
    description = models.TextField(null=True, blank=True, verbose_name='توضیحات کالا')
    image = models.ImageField(upload_to=product_image_path, null=True, blank=True, verbose_name='تصویر کالا')
    price = models.PositiveIntegerField(default=0, verbose_name='قیمت کالا')
    product_group = models.ManyToManyField(Product_Group, verbose_name='گروه کالا', related_name='products_of_groups')
    features = models.ManyToManyField(Feature, through='ProductFeature', verbose_name='ویژگی محصول')
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE, blank=True, null=True, verbose_name='برند کالا', related_name='product_of_brands')
    is_active = models.BooleanField(default=True, blank=True, verbose_name='وضعیت فعال/غیرفعال')
    register_date = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ درج')
    publish_date = models.DateTimeField(default=timezone.now, verbose_name='تاریخ انتشار')
    update_date = models.DateTimeField(auto_now=True, verbose_name='تاریخ آخرین بروزرسانی')
    slug = models.SlugField(max_length=200)
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = 'کالا'
        verbose_name_plural = 'کالا ها'
    
    def get_absolute_url(self):
        return reverse("product_detail", kwargs={"slug": self.slug})
    
    
    # قیمت با تخفیف کالا
    def get_price_by_discount(self):
        list1 =[]
        for dbd in self.discount_basket_details2.all():
            if (dbd.discount_basket.is_active==True and
                dbd.discount_basket.start_date <= datetime.now() and
                datetime.now() <= dbd.discount_basket.end_date):
                list1.append(dbd.discount_basket.discount)
        discount = 0
        if len(list1) > 0 :
            discount = max(list1)
        return self.price - (self.price * discount / 100)
    
    
    # میزان امتیازی که کاربر جاری به این کالا داده
    def get_user_score(self):
        request = RequestMiddleware(get_response=None)
        request = request.thread_local.current_request
        score=0
        user_score=self.scoring_product.filter(scoring_user=request.user)
        if user_score.count()>0:
            score = user_score[0].score
        return score

    # میانگین امتیازی که این کالا کسب کرده
    def get_average_score(self):
        avgScore = self.scoring_product.all().aggregate(Avg('score'))['score__avg']
        if avgScore == None:
            avgScore = 0
        return avgScore

    # آیا این کالا مورد علاقه کابر جاری بوده یا خیر
    def get_user_favorite(self):
        request = RequestMiddleware(get_response=None)
        request = request.thread_local.current_request
        flag = self.favorite_product.filter(favorite_user=request.user).exists()
        return flag

    # تابعی برای برگرداندن گروه اصلی کالا
    def getMainProductGroups(self):
        return self.product_group.all()[0].id



# Product - Feature -------------------------------------------------------------------------------
class ProductFeature(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='کالا', related_name='product_features')
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE, verbose_name='ویژگی')
    value = models.CharField(max_length=100, verbose_name='مقدار ویژگی کالا', null=True, blank=True)
    
    def __str__(self):
        return f'{self.product} - {self.feature} : {self.value}'

    class Meta:
        verbose_name = 'ویژگی محصول'
        verbose_name_plural = 'ویژگی‌های محصولات'


# Gallery -----------------------------------------------------------------------------------------
def gallery_image_path(instance, filename):
    filename, ext = os.path.splitext(filename)
    return f'images/product_pic/{instance.product.slug}/gallery/{uuid4()}{ext}'
class Gallery(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='کالا', related_name='gallery_images')
    image_name = models.ImageField(upload_to=gallery_image_path, verbose_name='تصویر کالا')
    
    class Meta:
        verbose_name = 'تصویر'
        verbose_name_plural = 'تصاویر'
