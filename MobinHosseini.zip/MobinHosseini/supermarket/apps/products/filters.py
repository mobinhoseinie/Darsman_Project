# apps/products/filters.py
import django_filters
from django import forms
from .models import Product, Brand, Product_Group
from django.db.models import Q

class ProductFilter(django_filters.FilterSet):
    
    brand = django_filters.ModelChoiceFilter(
        field_name='brand',
        queryset=Brand.objects.all(),
        label='برند',
        empty_label='— همه برندها —',
    )

    class Meta:
        model = Product
        fields = ['brand']
