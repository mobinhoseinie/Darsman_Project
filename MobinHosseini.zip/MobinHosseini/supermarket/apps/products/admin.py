from django.contrib import admin
from django.utils.html import format_html
from .models import Brand,Product_Group,Feature,Product,ProductFeature,Gallery

# BRAND -------------------------------------------------------------------------------------------
@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    list_display = ['title', 'slug', 'image_preview']
    list_filter = ('title',)
    search_fields = ('title',)
    ordering = ('title',)

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" />', obj.image.url)
        return "-"
    image_preview.short_description = 'تصویر'


# Product Group -----------------------------------------------------------------------------------
class Product_GroupInline(admin.TabularInline):
    model = Product_Group
    extra = 3

@admin.register(Product_Group)
class Product_GroupAdmin(admin.ModelAdmin):
    list_display = ['title', 'is_active', 'group_parent', 'slug', 'publish_date']
    list_filter = ['is_active']
    search_fields = ('title',)
    ordering = ('title',)
    inlines = [Product_GroupInline]
    list_editable = ['is_active']


# Feature -----------------------------------------------------------------------------------------
@admin.register(Feature)
class FeatureAdmin(admin.ModelAdmin):
    list_display = ['title']
    ordering = ['title']


# Product -----------------------------------------------------------------------------------------
class ProductFeatureInline(admin.TabularInline):
    model = ProductFeature
    extra=3

class GalleryInline(admin.TabularInline):
    model = Gallery
    extra = 3

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active', 'price', 'brand', 'update_date', 'slug',)
    list_filter = ('is_active',)
    search_fields = ('name',)
    ordering = ('update_date', 'name',)
    inlines = [ProductFeatureInline, GalleryInline]
    list_editable = ['is_active']
    


