from django.urls import path
from . import views

app_name = 'products'
urlpatterns = [
    path('categories/', views.ProductCategories.as_view(), name='categories'),
    path('<slug:slug>/', views.ProductDetailView.as_view(), name='product_detail'),
    path('group/<slug:slug>/', views.ProductsOfGroup.as_view(), name='products_of_group'),
]
