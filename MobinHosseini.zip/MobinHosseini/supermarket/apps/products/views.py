from django.shortcuts import render,get_object_or_404
from django.views import View
from .models import Product_Group,Product
from django.db.models import Q,Count
from django.views.generic import DetailView
from .filters import ProductFilter

def navbar_category(request):
        product_groups = Product_Group.objects.filter(
            is_active = True,
            group_parent = None,
        ).prefetch_related('groups')
        return render(request, "products_app/partials/navbar_category.html", {'product_groups':product_groups})


# محبوب ترین دسته ها ---------------------------------------------------------------
def get_popular_product_groups(request):
        product_groups = Product_Group.objects.filter(Q(is_active=True) & ~Q(group_parent = None)).annotate(count=Count('products_of_groups')).order_by('-count')[:3]
        return render(request, "products_app/partials/popular_product_groups.html", {'product_groups':product_groups})



# ارزان ترین محصولات ---------------------------------------------------------------
def get_cheapest_products(request):
    products = Product.objects.filter(is_active=True).order_by('price')[:5]
    context = {
        "products" : products,
    }
    return render(request, "products_app/cheapest_products.html", context)


# جدیدترین محصولات ---------------------------------------------------------------
def get_last_products(request, *args, **kwargs):
    products = Product.objects.filter(is_active=True).order_by('-publish_date')[:5]
    context = {
        "products" : products,
    }
    return render(request, "products_app/last_products.html", context)


# صفحه‌ی تمامی دسته بندی‌ها -----------------------------------------------------------------------
class ProductCategories(View):
    def get(self, request):
        product_groups = Product_Group.objects.filter(Q(is_active=True) & ~Q(group_parent = None)).annotate(count=Count('products_of_groups')).order_by('-count')
        context = {
             'product_groups':product_groups,
        }
        return render(request, "products_app/product_categories.html", context)


# صفحه جزئیات هر محصول ----------------------------------------------------------------------------
class ProductDetailView(DetailView) :
    model = Product
    template_name = "products_app/product_detail.html"
    context_object_name = "product"
    slug_field = "slug"
    slug_url_kwarg = "slug"



# محصولات مرتبط -----------------------------------------------------------------------------------
def get_related_products(request, slug):
    current_product = Product.objects.get(slug=slug)
    related_products = []
    for group in current_product.product_group.all():
        related_products.extend(Product.objects.filter(Q(is_active=True) & Q(product_group=group) & ~Q(id=current_product.id)))
    return render(request, "products_app/partials/related_products.html", {'related_products':related_products})

# محصولات هر گروه با فیلتر ------------------------------------------------------------------------
class ProductsOfGroup(View):
    def get(self, request, slug):

        all_groups = Product_Group.objects.filter(Q(is_active=True) & ~Q(group_parent = None)).annotate(count=Count('products_of_groups')).order_by('-count')

        product_group = get_object_or_404(Product_Group, slug=slug)

        base_qs = Product.objects.filter(
            is_active=True,
            product_group=product_group
        ).select_related('brand').prefetch_related('product_group')

        f = ProductFilter(request.GET, queryset=base_qs)

        context = {
            'products': f.qs,
            'product_group': product_group,
            'filter': f,
            'all_groups': all_groups,
        }
        return render(request, "products_app/products_list.html", context)









