def create_random_code(count):
    import random
    count-=1
    return random.randint(10**count, 10**(count+1)-1)



# ----------------------------------------------------------
def price_by_delivery_tax(price, discount=0):
    delivery = 25000
    if price > 500000 :
        delivery = 0
    tax = (price+delivery)*0.09
    sum = price+delivery+tax
    sum = sum - (sum*discount/100)
    return int(sum),delivery,int(tax)
