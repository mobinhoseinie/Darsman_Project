-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: db_supermarket
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_user`
--

DROP TABLE IF EXISTS `accounts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `mobile_number` varchar(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `family` varchar(50) NOT NULL,
  `email` varchar(254) NOT NULL,
  `address` longtext NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `register_date` datetime(6) NOT NULL,
  `active_code` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_number` (`mobile_number`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user`
--

LOCK TABLES `accounts_user` WRITE;
/*!40000 ALTER TABLE `accounts_user` DISABLE KEYS */;
INSERT INTO `accounts_user` VALUES (1,'pbkdf2_sha256$1000000$FTO13iNruAQV3sSVeKpv5v$XOFjKg/lzYd4rYPoYdIIyzmwYElNHBJn9CdET46GV2U=','2025-08-19 17:08:33.798375',1,'0901','admin','admini','admin@admin.com','','','2025-08-13 23:12:42.768362','810658',1,1),(2,'pbkdf2_sha256$1000000$U99xBurWjzxX1yGIFM5b6Q$/9W3/nw4FvDP3uz2BAtJWKA2rDVinsSjES4hsF4S070=','2025-08-17 17:05:39.617522',0,'0902','علی','رضایی','ali@yahoo.com','ملایر - خیابان شهدا','','2025-08-13 23:13:30.719930','291904',1,0),(3,'pbkdf2_sha256$1000000$DGVLhs2kOC8OQENC07UHQb$HfcJxbA8k4UrZbBz+eg03vUr9NayYLVlgBiYc43su6s=','2025-08-19 22:02:20.562138',0,'0903','مبین','حسینی','mobin@yahoo.com','ملایر - خیابان شهید مصطفی خمینی','','2025-08-16 01:27:38.843326','582896',1,0),(4,'pbkdf2_sha256$1000000$x8siANEmny4VJdYfD0fJHN$HsAZfhy9pzPnwUxnN6HoUrGHMMhLWfMYV9LAzZwvJco=','2025-08-16 17:46:32.496616',0,'0904','سینا','کریمی','sina@yahoo.com','تهران - ونک','','2025-08-16 02:12:45.793437','124238',1,0),(5,'pbkdf2_sha256$1000000$Vvxca2aRiE6v4RW3yImkY7$ZM+qlel2nf7W21nvDdFbBL2EV/YukVsMPiFbzPjQ/2c=','2025-08-19 16:37:56.092092',0,'0909','علی','کریمی','ali@karimi.com','شیراز','images/users_pic/0909/d5cf2626-e98d-4e7a-a05e-07c3b5acbbbf.jpg','2025-08-19 16:35:45.148332','777343',0,0);
/*!40000 ALTER TABLE `accounts_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_user_groups`
--

DROP TABLE IF EXISTS `accounts_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_user_groups_user_id_group_id_59c0b32f_uniq` (`user_id`,`group_id`),
  KEY `accounts_user_groups_group_id_bd11a704_fk_auth_group_id` (`group_id`),
  CONSTRAINT `accounts_user_groups_group_id_bd11a704_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `accounts_user_groups_user_id_52b62117_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user_groups`
--

LOCK TABLES `accounts_user_groups` WRITE;
/*!40000 ALTER TABLE `accounts_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_user_user_permissions`
--

DROP TABLE IF EXISTS `accounts_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_user_user_permi_user_id_permission_id_2ab516c2_uniq` (`user_id`,`permission_id`),
  KEY `accounts_user_user_p_permission_id_113bb443_fk_auth_perm` (`permission_id`),
  CONSTRAINT `accounts_user_user_p_permission_id_113bb443_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `accounts_user_user_p_user_id_e4f0a161_fk_accounts_` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user_user_permissions`
--

LOCK TABLES `accounts_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `accounts_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add پیام',6,'add_contactmessage'),(22,'Can change پیام',6,'change_contactmessage'),(23,'Can delete پیام',6,'delete_contactmessage'),(24,'Can view پیام',6,'view_contactmessage'),(25,'Can add کاربر',7,'add_user'),(26,'Can change کاربر',7,'change_user'),(27,'Can delete کاربر',7,'delete_user'),(28,'Can view کاربر',7,'view_user'),(29,'Can add ویژگی محصول',8,'add_productfeature'),(30,'Can change ویژگی محصول',8,'change_productfeature'),(31,'Can delete ویژگی محصول',8,'delete_productfeature'),(32,'Can view ویژگی محصول',8,'view_productfeature'),(33,'Can add تصویر',9,'add_gallery'),(34,'Can change تصویر',9,'change_gallery'),(35,'Can delete تصویر',9,'delete_gallery'),(36,'Can view تصویر',9,'view_gallery'),(37,'Can add برند',10,'add_brand'),(38,'Can change برند',10,'change_brand'),(39,'Can delete برند',10,'delete_brand'),(40,'Can view برند',10,'view_brand'),(41,'Can add ویژگی',11,'add_feature'),(42,'Can change ویژگی',11,'change_feature'),(43,'Can delete ویژگی',11,'delete_feature'),(44,'Can view ویژگی',11,'view_feature'),(45,'Can add گروه کالا',12,'add_product_group'),(46,'Can change گروه کالا',12,'change_product_group'),(47,'Can delete گروه کالا',12,'delete_product_group'),(48,'Can view گروه کالا',12,'view_product_group'),(49,'Can add کالا',13,'add_product'),(50,'Can change کالا',13,'change_product'),(51,'Can delete کالا',13,'delete_product'),(52,'Can view کالا',13,'view_product'),(53,'Can add نظر',14,'add_comment'),(54,'Can change نظر',14,'change_comment'),(55,'Can delete نظر',14,'delete_comment'),(56,'Can view نظر',14,'view_comment'),(57,'Can add علاقه',15,'add_favorite'),(58,'Can change علاقه',15,'change_favorite'),(59,'Can delete علاقه',15,'delete_favorite'),(60,'Can view علاقه',15,'view_favorite'),(61,'Can add امتیاز',16,'add_scoring'),(62,'Can change امتیاز',16,'change_scoring'),(63,'Can delete امتیاز',16,'delete_scoring'),(64,'Can view امتیاز',16,'view_scoring'),(65,'Can add اسلاید',17,'add_slider'),(66,'Can change اسلاید',17,'change_slider'),(67,'Can delete اسلاید',17,'delete_slider'),(68,'Can view اسلاید',17,'view_slider'),(69,'Can add order details',18,'add_orderdetails'),(70,'Can change order details',18,'change_orderdetails'),(71,'Can delete order details',18,'delete_orderdetails'),(72,'Can view order details',18,'view_orderdetails'),(73,'Can add سفارش',19,'add_order'),(74,'Can change سفارش',19,'change_order'),(75,'Can delete سفارش',19,'delete_order'),(76,'Can view سفارش',19,'view_order'),(77,'Can add نوع پرداخت',20,'add_paymenttype'),(78,'Can change نوع پرداخت',20,'change_paymenttype'),(79,'Can delete نوع پرداخت',20,'delete_paymenttype'),(80,'Can view نوع پرداخت',20,'view_paymenttype'),(81,'Can add کوپن تخفیف',21,'add_coupon'),(82,'Can change کوپن تخفیف',21,'change_coupon'),(83,'Can delete کوپن تخفیف',21,'delete_coupon'),(84,'Can view کوپن تخفیف',21,'view_coupon'),(85,'Can add جزئیات سبد تخفیف',22,'add_discountbasketdetails'),(86,'Can change جزئیات سبد تخفیف',22,'change_discountbasketdetails'),(87,'Can delete جزئیات سبد تخفیف',22,'delete_discountbasketdetails'),(88,'Can view جزئیات سبد تخفیف',22,'view_discountbasketdetails'),(89,'Can add سبد تخفیف',23,'add_discountbasket'),(90,'Can change سبد تخفیف',23,'change_discountbasket'),(91,'Can delete سبد تخفیف',23,'delete_discountbasket'),(92,'Can view سبد تخفیف',23,'view_discountbasket');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_scoring_favorites_comment`
--

DROP TABLE IF EXISTS `comment_scoring_favorites_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_scoring_favorites_comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `comment_text` longtext NOT NULL,
  `registerdate` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `approving_user_id` bigint DEFAULT NULL,
  `comment_parent_id` bigint DEFAULT NULL,
  `commenting_user_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_scoring_favo_approving_user_id_25e116f1_fk_accounts_` (`approving_user_id`),
  KEY `comment_scoring_favo_comment_parent_id_bc33ff60_fk_comment_s` (`comment_parent_id`),
  KEY `comment_scoring_favo_commenting_user_id_f48496b9_fk_accounts_` (`commenting_user_id`),
  KEY `comment_scoring_favo_product_id_16b120b4_fk_products_` (`product_id`),
  CONSTRAINT `comment_scoring_favo_approving_user_id_25e116f1_fk_accounts_` FOREIGN KEY (`approving_user_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `comment_scoring_favo_comment_parent_id_bc33ff60_fk_comment_s` FOREIGN KEY (`comment_parent_id`) REFERENCES `comment_scoring_favorites_comment` (`id`),
  CONSTRAINT `comment_scoring_favo_commenting_user_id_f48496b9_fk_accounts_` FOREIGN KEY (`commenting_user_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `comment_scoring_favo_product_id_16b120b4_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_scoring_favorites_comment`
--

LOCK TABLES `comment_scoring_favorites_comment` WRITE;
/*!40000 ALTER TABLE `comment_scoring_favorites_comment` DISABLE KEYS */;
INSERT INTO `comment_scoring_favorites_comment` VALUES (1,'خوب بود','2025-08-16 17:45:20.735959',1,NULL,NULL,3,2),(2,'موافقم','2025-08-16 17:46:44.030479',1,NULL,1,4,2);
/*!40000 ALTER TABLE `comment_scoring_favorites_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_scoring_favorites_favorite`
--

DROP TABLE IF EXISTS `comment_scoring_favorites_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_scoring_favorites_favorite` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `register_date` datetime(6) NOT NULL,
  `favorite_user_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_scoring_favo_favorite_user_id_c5146b93_fk_accounts_` (`favorite_user_id`),
  KEY `comment_scoring_favo_product_id_45b406cd_fk_products_` (`product_id`),
  CONSTRAINT `comment_scoring_favo_favorite_user_id_c5146b93_fk_accounts_` FOREIGN KEY (`favorite_user_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `comment_scoring_favo_product_id_45b406cd_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_scoring_favorites_favorite`
--

LOCK TABLES `comment_scoring_favorites_favorite` WRITE;
/*!40000 ALTER TABLE `comment_scoring_favorites_favorite` DISABLE KEYS */;
INSERT INTO `comment_scoring_favorites_favorite` VALUES (1,'2025-08-17 17:30:09.174909',3,2),(2,'2025-08-19 16:38:23.559174',5,3),(3,'2025-08-19 16:43:49.446241',5,7);
/*!40000 ALTER TABLE `comment_scoring_favorites_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_scoring_favorites_scoring`
--

DROP TABLE IF EXISTS `comment_scoring_favorites_scoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_scoring_favorites_scoring` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `registerdate` datetime(6) NOT NULL,
  `score` smallint unsigned NOT NULL,
  `product_id` bigint NOT NULL,
  `scoring_user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_scoring_favo_product_id_38c2dbe8_fk_products_` (`product_id`),
  KEY `comment_scoring_favo_scoring_user_id_33462d7e_fk_accounts_` (`scoring_user_id`),
  CONSTRAINT `comment_scoring_favo_product_id_38c2dbe8_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `comment_scoring_favo_scoring_user_id_33462d7e_fk_accounts_` FOREIGN KEY (`scoring_user_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `comment_scoring_favorites_scoring_chk_1` CHECK ((`score` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_scoring_favorites_scoring`
--

LOCK TABLES `comment_scoring_favorites_scoring` WRITE;
/*!40000 ALTER TABLE `comment_scoring_favorites_scoring` DISABLE KEYS */;
INSERT INTO `comment_scoring_favorites_scoring` VALUES (1,'2025-08-17 17:05:47.061483',3,2,2),(2,'2025-08-17 17:06:20.713061',4,2,3);
/*!40000 ALTER TABLE `comment_scoring_favorites_scoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts_coupon`
--

DROP TABLE IF EXISTS `discounts_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discounts_coupon` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `coupon_code` varchar(10) NOT NULL,
  `start_date` datetime(6) NOT NULL,
  `end_date` datetime(6) NOT NULL,
  `discount` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupon_code` (`coupon_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts_coupon`
--

LOCK TABLES `discounts_coupon` WRITE;
/*!40000 ALTER TABLE `discounts_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts_discountbasket`
--

DROP TABLE IF EXISTS `discounts_discountbasket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discounts_discountbasket` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `discount_title` varchar(100) NOT NULL,
  `start_date` datetime(6) NOT NULL,
  `end_date` datetime(6) NOT NULL,
  `discount` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts_discountbasket`
--

LOCK TABLES `discounts_discountbasket` WRITE;
/*!40000 ALTER TABLE `discounts_discountbasket` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts_discountbasket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discounts_discountbasketdetails`
--

DROP TABLE IF EXISTS `discounts_discountbasketdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `discounts_discountbasketdetails` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `discount_basket_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discounts_discountba_discount_basket_id_bf6bb9b3_fk_discounts` (`discount_basket_id`),
  KEY `discounts_discountba_product_id_0a8a924c_fk_products_` (`product_id`),
  CONSTRAINT `discounts_discountba_discount_basket_id_bf6bb9b3_fk_discounts` FOREIGN KEY (`discount_basket_id`) REFERENCES `discounts_discountbasket` (`id`),
  CONSTRAINT `discounts_discountba_product_id_0a8a924c_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discounts_discountbasketdetails`
--

LOCK TABLES `discounts_discountbasketdetails` WRITE;
/*!40000 ALTER TABLE `discounts_discountbasketdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts_discountbasketdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_accounts_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2025-08-14 03:41:27.604444','1','هراز',1,'[{\"added\": {}}]',10,1),(2,'2025-08-14 03:42:19.068707','2','کاله',1,'[{\"added\": {}}]',10,1),(3,'2025-08-14 03:43:45.114355','3','عالیس',1,'[{\"added\": {}}]',10,1),(4,'2025-08-14 03:44:51.820105','4','پگاه',1,'[{\"added\": {}}]',10,1),(5,'2025-08-14 03:45:17.744338','5','میهن',1,'[{\"added\": {}}]',10,1),(6,'2025-08-14 03:48:45.705751','1','لبنیات',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0634\\u06cc\\u0631\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u067e\\u0646\\u06cc\\u0631\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u062e\\u0627\\u0645\\u0647\"}}]',12,1),(7,'2025-08-14 03:50:52.172094','5','نوشیدنی',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0646\\u0648\\u0634\\u0627\\u0628\\u0647\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0622\\u0628\\u0645\\u06cc\\u0648\\u0647\"}}]',12,1),(8,'2025-08-14 03:52:21.350433','1','وزن',1,'[{\"added\": {}}]',11,1),(9,'2025-08-14 03:52:26.854671','2','حجم',1,'[{\"added\": {}}]',11,1),(10,'2025-08-14 03:57:32.747218','1','شیر کم چرب مدت دار هراز',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u0634\\u06cc\\u0631 \\u06a9\\u0645 \\u0686\\u0631\\u0628 \\u0645\\u062f\\u062a \\u062f\\u0627\\u0631 \\u0647\\u0631\\u0627\\u0632 - \\u062d\\u062c\\u0645 : 1 \\u0644\\u06cc\\u062a\\u0631\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (1)\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (2)\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (3)\"}}]',13,1),(11,'2025-08-14 04:02:05.506064','2','شیر پرچرب مدت دار هراز',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u0634\\u06cc\\u0631 \\u067e\\u0631\\u0686\\u0631\\u0628 \\u0645\\u062f\\u062a \\u062f\\u0627\\u0631 \\u0647\\u0631\\u0627\\u0632 - \\u062d\\u062c\\u0645 : 200 \\u0645\\u06cc\\u0644\\u06cc \\u0644\\u06cc\\u062a\\u0631\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (4)\"}}]',13,1),(12,'2025-08-14 04:05:18.653537','6','کوکاکولا',1,'[{\"added\": {}}]',10,1),(13,'2025-08-14 04:05:47.138634','3','نوشابه کوکاکولا',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u0646\\u0648\\u0634\\u0627\\u0628\\u0647 \\u06a9\\u0648\\u06a9\\u0627\\u06a9\\u0648\\u0644\\u0627 - \\u062d\\u062c\\u0645 : 1.5 \\u0644\\u06cc\\u062a\\u0631\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (5)\"}}]',13,1),(14,'2025-08-14 12:09:26.217901','8','کنسرو و غذای آماده',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u062a\\u0646 \\u0645\\u0627\\u0647\\u06cc\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u06a9\\u0646\\u0633\\u0631\\u0648 \\u0648 \\u06a9\\u0645\\u067e\\u0648\\u062a\"}}]',12,1),(15,'2025-08-14 12:12:30.072064','11','صبحانه',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0639\\u0633\\u0644\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0645\\u0631\\u0628\\u0627\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0634\\u06a9\\u0644\\u0627\\u062a \\u0635\\u0628\\u062d\\u0627\\u0646\\u0647\"}}]',12,1),(16,'2025-08-14 12:14:28.806371','15','چاشنی و افزودنی',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0633\\u0633\"}}, {\"added\": {\"name\": \"\\u06af\\u0631\\u0648\\u0647 \\u06a9\\u0627\\u0644\\u0627\", \"object\": \"\\u0627\\u062f\\u0648\\u06cc\\u0647\"}}]',12,1),(17,'2025-08-14 12:18:25.395087','4','بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u0628\\u0633\\u062a\\u0647 \\u06f3 \\u0639\\u062f\\u062f\\u06cc \\u067e\\u0646\\u06cc\\u0631 \\u062a\\u0627\\u067e\\u06cc\\u0646\\u06af \\u067e\\u06cc\\u062a\\u0632\\u0627 \\u06a9\\u0645 \\u0686\\u0631\\u0628 \\u0631\\u0646\\u062f\\u0647 \\u0634\\u062f\\u0647 \\u06a9\\u0627\\u0644\\u0647 - \\u0648\\u0632\\u0646 : 500 \\u06af\\u0631\\u0645\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (6)\"}}]',13,1),(18,'2025-08-14 12:21:26.542449','5','پنیر خامه ای پرچرب ویلی کاله',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u067e\\u0646\\u06cc\\u0631 \\u062e\\u0627\\u0645\\u0647 \\u0627\\u06cc \\u067e\\u0631\\u0686\\u0631\\u0628 \\u0648\\u06cc\\u0644\\u06cc \\u06a9\\u0627\\u0644\\u0647 - \\u0648\\u0632\\u0646 : 200 \\u06af\\u0631\\u0645\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (7)\"}}]',13,1),(19,'2025-08-14 12:24:20.888137','6','پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u067e\\u0646\\u06cc\\u0631 \\u0633\\u0641\\u06cc\\u062f \\u0646\\u06cc\\u0645 \\u0686\\u0631\\u0628 \\u062d\\u0627\\u0648\\u06cc \\u0648\\u06cc\\u062a\\u0627\\u0645\\u06cc\\u0646 D\\u06f3 \\u067e\\u06af\\u0627\\u0647 - \\u0648\\u0632\\u0646 : 400 \\u06af\\u0631\\u0645\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (8)\"}}]',13,1),(20,'2025-08-14 17:22:22.519207','3','پنیر',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(21,'2025-08-14 17:23:57.822245','4','خامه',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(22,'2025-08-14 17:24:37.993249','2','شیر',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(23,'2025-08-14 17:25:35.597210','7','آبمیوه',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(24,'2025-08-14 17:26:14.448247','6','نوشابه',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(25,'2025-08-14 17:26:48.955399','9','تن ماهی',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(26,'2025-08-14 17:27:31.391507','10','کنسرو و کمپوت',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(27,'2025-08-14 17:27:51.756639','14','شکلات صبحانه',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(28,'2025-08-14 17:28:18.879340','12','عسل',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(29,'2025-08-14 17:28:42.169665','13','مربا',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(30,'2025-08-14 17:29:09.832520','17','ادویه',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(31,'2025-08-14 17:29:37.394922','16','سس',2,'[{\"changed\": {\"fields\": [\"\\u062a\\u0635\\u0648\\u06cc\\u0631 \\u06a9\\u0627\\u0644\\u0627\"]}}]',12,1),(32,'2025-08-14 17:59:38.349710','7','خامه نیم چرب هراز',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u062e\\u0627\\u0645\\u0647 \\u0646\\u06cc\\u0645 \\u0686\\u0631\\u0628 \\u0647\\u0631\\u0627\\u0632 - \\u062d\\u062c\\u0645 : 200 \\u0645\\u06cc\\u0644\\u06cc\\u200c\\u0644\\u06cc\\u062a\\u0631\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (9)\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (10)\"}}]',13,1),(33,'2025-08-14 18:04:09.108204','7','خوشبخت',1,'[{\"added\": {}}]',10,1),(34,'2025-08-14 18:05:12.470972','8','کنسرو ماهی تون در روغن گیاهی خوشبخت',1,'[{\"added\": {}}, {\"added\": {\"name\": \"\\u0648\\u06cc\\u0698\\u06af\\u06cc \\u0645\\u062d\\u0635\\u0648\\u0644\", \"object\": \"\\u06a9\\u0646\\u0633\\u0631\\u0648 \\u0645\\u0627\\u0647\\u06cc \\u062a\\u0648\\u0646 \\u062f\\u0631 \\u0631\\u0648\\u063a\\u0646 \\u06af\\u06cc\\u0627\\u0647\\u06cc \\u062e\\u0648\\u0634\\u0628\\u062e\\u062a - \\u0648\\u0632\\u0646 : 180\\u06af\\u0631\\u0645\\u06cc\"}}, {\"added\": {\"name\": \"\\u062a\\u0635\\u0648\\u06cc\\u0631\", \"object\": \"Gallery object (11)\"}}]',13,1),(35,'2025-08-16 17:46:10.956209','1','شیر پرچرب مدت دار هراز-مبین حسینی - 0903',2,'[{\"changed\": {\"fields\": [\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0646\\u0638\\u0631\"]}}]',14,1),(36,'2025-08-16 17:47:04.255156','2','شیر پرچرب مدت دار هراز-سینا کریمی - 0904',2,'[{\"changed\": {\"fields\": [\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0646\\u0638\\u0631\"]}}]',14,1),(37,'2025-08-17 17:57:39.755453','1','محصولات هراز',1,'[{\"added\": {}}]',17,1),(38,'2025-08-17 17:59:07.976986','2','میهن',1,'[{\"added\": {}}]',17,1),(39,'2025-08-19 17:09:11.591180','5','علی کریمی - 0909',2,'[{\"changed\": {\"fields\": [\"\\u0648\\u0636\\u0639\\u06cc\\u062a \\u0641\\u0639\\u0627\\u0644/\\u063a\\u06cc\\u0631\\u0641\\u0639\\u0627\\u0644\"]}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (7,'accounts','user'),(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(14,'comment_scoring_favorites','comment'),(15,'comment_scoring_favorites','favorite'),(16,'comment_scoring_favorites','scoring'),(4,'contenttypes','contenttype'),(21,'discounts','coupon'),(23,'discounts','discountbasket'),(22,'discounts','discountbasketdetails'),(6,'main','contactmessage'),(17,'main','slider'),(19,'orders','order'),(18,'orders','orderdetails'),(20,'orders','paymenttype'),(10,'products','brand'),(11,'products','feature'),(9,'products','gallery'),(13,'products','product'),(12,'products','product_group'),(8,'products','productfeature'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-08-13 23:12:04.035409'),(2,'contenttypes','0002_remove_content_type_name','2025-08-13 23:12:04.194305'),(3,'auth','0001_initial','2025-08-13 23:12:04.447153'),(4,'auth','0002_alter_permission_name_max_length','2025-08-13 23:12:04.522199'),(5,'auth','0003_alter_user_email_max_length','2025-08-13 23:12:04.529768'),(6,'auth','0004_alter_user_username_opts','2025-08-13 23:12:04.536418'),(7,'auth','0005_alter_user_last_login_null','2025-08-13 23:12:04.545301'),(8,'auth','0006_require_contenttypes_0002','2025-08-13 23:12:04.547101'),(9,'auth','0007_alter_validators_add_error_messages','2025-08-13 23:12:04.557955'),(10,'auth','0008_alter_user_username_max_length','2025-08-13 23:12:04.563073'),(11,'auth','0009_alter_user_last_name_max_length','2025-08-13 23:12:04.571913'),(12,'auth','0010_alter_group_name_max_length','2025-08-13 23:12:04.590696'),(13,'auth','0011_update_proxy_permissions','2025-08-13 23:12:04.599971'),(14,'auth','0012_alter_user_first_name_max_length','2025-08-13 23:12:04.609352'),(15,'accounts','0001_initial','2025-08-13 23:12:04.943901'),(16,'accounts','0002_alter_user_name','2025-08-13 23:12:05.021631'),(17,'accounts','0003_alter_user_address_alter_user_family','2025-08-13 23:12:05.158917'),(18,'accounts','0004_alter_user_address_alter_user_email_and_more','2025-08-13 23:12:05.494914'),(19,'admin','0001_initial','2025-08-13 23:12:05.641653'),(20,'admin','0002_logentry_remove_auto_add','2025-08-13 23:12:05.659424'),(21,'admin','0003_logentry_add_action_flag_choices','2025-08-13 23:12:05.664351'),(22,'main','0001_initial','2025-08-13 23:12:05.689068'),(23,'sessions','0001_initial','2025-08-13 23:12:05.735122'),(24,'products','0001_initial','2025-08-14 03:37:49.126825'),(25,'comment_scoring_favorites','0001_initial','2025-08-16 16:17:04.826080'),(26,'comment_scoring_favorites','0002_favorite_scoring','2025-08-16 17:51:48.624848'),(27,'comment_scoring_favorites','0003_alter_scoring_score','2025-08-17 17:42:00.969834'),(28,'main','0002_slider','2025-08-17 17:42:00.992524'),(29,'orders','0001_initial','2025-08-18 18:10:18.922764'),(30,'orders','0002_paymenttype_order_description_order_payment_type','2025-08-19 13:30:39.792578'),(31,'discounts','0001_initial','2025-08-19 13:40:13.248294');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('2290izjoavrbhu3h0bvaoumls7og7zxu','eyJ1c2VyX3Nlc3Npb24iOnsibW9iaWxlX251bWJlciI6IjA5MDIifX0:1umJFa:EhV-nYd8HWn5Vap-4WZHPuqrPSgftwXNjL7RQSNUGFY','2025-08-28 01:13:14.001814'),('8e19sk1gze2kgwkee0juv6mufu1f2dyr','.eJxdjMsOgjAQRf9l1qSB0mkpS_d-Q9PHVFADyGNhCP8uGELEzWRy7z1nhqFqO-NtP0I5A9_Oa3xDmSXQ9bWn9ZM6TROIdWOf5jdj6ZJAfhD8IFCh-Ce-2UqsiLHTWJlpoN7UAcpVccqc9Q9qtiLcbXNrmW-bsa8d2yZsbwd2bQM9L_v2JKjsUG1aUtFFLUIMHDONLvfBE0mBVJCMshA26kgF5wJ5JonrXIng0shVhmgRlg8y11mr:1uoKmy:BGCWw_B0q_yk6hMv4MZ6Pu4_oJxrN-dyJTTLwzAcrXc','2025-09-02 15:16:04.553917'),('9e062whvbi3t1sp6279wj1g7aj45gi5b','eyJzaG9wX2NhcnQiOnt9fQ:1uoToX:PDDasDVy4e1uouv3fKLPfe0VUon8KGB5U9zLqlepaVk','2025-09-03 00:54:17.962535'),('o57g7llv579799n9dpw6e3gs0w3vu2pb','.eJyrVirOyC-IT04sKlGyqlYyAhGFJZVKVoY6SgVFmcmpQJaZpYGBjlJaZl5iTjyymJ5BrY6SGRYd5uamGDrAYkAdtbUA5kAiVA:1uoRT0:rroRMqrm719-AOOyw14iYww8kj8yPfd3lZiWxwDt7OM','2025-09-02 22:23:54.854282'),('p7ivomk1vkohz4vptycfnn776ujyd4p4','.eJyrVirOyC-IT04sKlGyqlYyBhGFJZVKVmY6SgVFmcmpSlam5qYmBjpKaZl5iTnxyGJ6BrW1tQCp7xQ4:1uoMql:AYzQhHvpo5P8g0__Jx5YOMYUfPrh1ImLB47M7F8H0cA','2025-09-02 17:28:07.841820'),('pk2l32w2fzx1nx8uon2r9yt2ythm9gut','.eJxVjDsOwjAQBe-yNbLWJv6Qkp4zWOu1jQMoRnFSRbk7REqT9s3MW6GV-vVM0wz9ul3A0zIXv7Q0-SFCDxJOWyB-p3EH8UXjswqu4zwNQeyKOGgTjxrT5364p4NCrfxre3XKaZOZdYcKMXXSSL65QFlFtDFo3YVgTbYYSaIjraJLRlqjVZbIsP0Ajbc8mQ:1uo14U:68V49zmiBIJQDoVTAWbs3wIL_-EBM0FnSggz09kJ9DU','2025-09-01 18:12:50.769691');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_contactmessage`
--

DROP TABLE IF EXISTS `main_contactmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `main_contactmessage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `text` longtext NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(254) NOT NULL,
  `date` datetime(6) NOT NULL,
  `is_seen` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_contactmessage`
--

LOCK TABLES `main_contactmessage` WRITE;
/*!40000 ALTER TABLE `main_contactmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `main_contactmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `main_slider`
--

DROP TABLE IF EXISTS `main_slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `main_slider` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `slider_title1` varchar(500) DEFAULT NULL,
  `slider_title2` varchar(500) DEFAULT NULL,
  `slider_title3` varchar(500) DEFAULT NULL,
  `image_name` varchar(100) NOT NULL,
  `slider_link` varchar(200) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `register_date` datetime(6) NOT NULL,
  `published_date` datetime(6) NOT NULL,
  `update_date` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `main_slider`
--

LOCK TABLES `main_slider` WRITE;
/*!40000 ALTER TABLE `main_slider` DISABLE KEYS */;
INSERT INTO `main_slider` VALUES (1,'محصولات هراز',NULL,NULL,'images/slider_pic/02512553-e097-4217-b9e8-9f03c3cbe84b.jpg',NULL,1,'2025-08-17 17:57:39.753457','2025-08-17 17:51:03.000000','2025-08-17 17:57:39.753457'),(2,'میهن',NULL,NULL,'images/slider_pic/ffdceacc-410c-4b27-ac27-9f49689b0b9a.webp',NULL,1,'2025-08-17 17:59:07.976986','2025-08-17 17:58:46.000000','2025-08-17 17:59:07.976986');
/*!40000 ALTER TABLE `main_slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_order`
--

DROP TABLE IF EXISTS `orders_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `register_date` date NOT NULL,
  `update_date` date NOT NULL,
  `is_finally` tinyint(1) NOT NULL,
  `order_code` char(32) NOT NULL,
  `discount` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `description` longtext,
  `payment_type_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `orders_order_user_id_e9b59eb1_fk_accounts_user_id` (`user_id`),
  KEY `orders_order_payment_type_id_fa27978f_fk_orders_paymenttype_id` (`payment_type_id`),
  CONSTRAINT `orders_order_payment_type_id_fa27978f_fk_orders_paymenttype_id` FOREIGN KEY (`payment_type_id`) REFERENCES `orders_paymenttype` (`id`),
  CONSTRAINT `orders_order_user_id_e9b59eb1_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_order`
--

LOCK TABLES `orders_order` WRITE;
/*!40000 ALTER TABLE `orders_order` DISABLE KEYS */;
INSERT INTO `orders_order` VALUES (1,'2025-08-19','2025-08-19',0,'fe84eb33af2b489cae1e2d15e50e41b1',0,3,NULL,1),(2,'2025-08-19','2025-08-19',0,'491e2a986049434bb9c1598add1e480d',0,3,NULL,1);
/*!40000 ALTER TABLE `orders_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_orderdetails`
--

DROP TABLE IF EXISTS `orders_orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_orderdetails` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `qty` int unsigned NOT NULL,
  `price` int NOT NULL,
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_orderdetails_order_id_d7985cfb_fk_orders_order_id` (`order_id`),
  KEY `orders_orderdetails_product_id_e66102b1_fk_products_product_id` (`product_id`),
  CONSTRAINT `orders_orderdetails_order_id_d7985cfb_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`),
  CONSTRAINT `orders_orderdetails_product_id_e66102b1_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `orders_orderdetails_chk_1` CHECK ((`qty` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_orderdetails`
--

LOCK TABLES `orders_orderdetails` WRITE;
/*!40000 ALTER TABLE `orders_orderdetails` DISABLE KEYS */;
INSERT INTO `orders_orderdetails` VALUES (1,1,16900,1,2),(2,1,77500,1,6),(3,1,16900,2,2),(4,1,77500,2,6);
/*!40000 ALTER TABLE `orders_orderdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders_paymenttype`
--

DROP TABLE IF EXISTS `orders_paymenttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_paymenttype` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `payment_title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_paymenttype`
--

LOCK TABLES `orders_paymenttype` WRITE;
/*!40000 ALTER TABLE `orders_paymenttype` DISABLE KEYS */;
INSERT INTO `orders_paymenttype` VALUES (1,'درگاه بانکی'),(2,'پرداخت در محل'),(3,'کیف پول'),(4,'فیش یانکی');
/*!40000 ALTER TABLE `orders_paymenttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_brand`
--

DROP TABLE IF EXISTS `products_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_brand` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_brand`
--

LOCK TABLES `products_brand` WRITE;
/*!40000 ALTER TABLE `products_brand` DISABLE KEYS */;
INSERT INTO `products_brand` VALUES (1,'هراز','haraz','images/brand_pic/haraz/c96d8384-793c-43b1-be4d-fc10f3c29f38.png'),(2,'کاله','kalleh','images/brand_pic/kalleh/a4d78450-adcb-424d-8f86-a87ad51dc74c.png'),(3,'عالیس','alis','images/brand_pic/alis/73f18cb5-8fa5-4dd4-964c-b935b40fc538.png'),(4,'پگاه','pegah','images/brand_pic/pegah/92836f94-34e9-49d4-b6b2-6708c671fe83.png'),(5,'میهن','mihan','images/brand_pic/mihan/0b45e75b-108b-4636-8f2c-85068995a9b8.png'),(6,'کوکاکولا','coca-cola','images/brand_pic/coca-cola/a2268f73-44e8-4bb1-a079-22e627b3ae9d.png'),(7,'خوشبخت','khoshbakht','images/brand_pic/khoshbakht/d195c2f8-648b-4e46-9ea8-1b0bd5609f8c.png');
/*!40000 ALTER TABLE `products_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_feature`
--

DROP TABLE IF EXISTS `products_feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_feature` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_feature`
--

LOCK TABLES `products_feature` WRITE;
/*!40000 ALTER TABLE `products_feature` DISABLE KEYS */;
INSERT INTO `products_feature` VALUES (1,'وزن'),(2,'حجم');
/*!40000 ALTER TABLE `products_feature` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_gallery`
--

DROP TABLE IF EXISTS `products_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_gallery` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image_name` varchar(100) NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_gallery_product_id_fb8f35f7_fk_products_product_id` (`product_id`),
  CONSTRAINT `products_gallery_product_id_fb8f35f7_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_gallery`
--

LOCK TABLES `products_gallery` WRITE;
/*!40000 ALTER TABLE `products_gallery` DISABLE KEYS */;
INSERT INTO `products_gallery` VALUES (1,'images/product_pic/milk-low-fat-haraz/gallery/5dac62d1-0ccb-4a77-ad0f-6f97fc7d2626.webp',1),(2,'images/product_pic/milk-low-fat-haraz/gallery/b32216cf-d704-4faf-9c82-4b56af23f9f4.webp',1),(3,'images/product_pic/milk-low-fat-haraz/gallery/897662cf-b073-45d7-98f8-4f14e6eac3c1.webp',1),(4,'images/product_pic/high-fat-haraz/gallery/1739d36f-7d56-4ba4-8f83-a93f012b35db.webp',2),(5,'images/product_pic/cola-cocacola/gallery/614b721b-d156-42c5-8896-54be6ba591d5.webp',3),(6,'images/product_pic/pizza-topping-cheese/gallery/9fb6828e-5f05-4875-b92e-ecd81c68068b.webp',4),(7,'images/product_pic/full-fat-cream-cheese/gallery/510e727a-89e0-49c4-9f91-4f3716989b12.webp',5),(8,'images/product_pic/white-cheese-containing-vitamin-D3/gallery/602f3eee-c3f4-4795-b8a6-4_acF13uK.webp',6),(9,'images/product_pic/semi-fat-cream/gallery/0dffa155-63d4-4f04-b2b1-6a343f53da9a.webp',7),(10,'images/product_pic/semi-fat-cream/gallery/e85b4f3e-42e8-4f02-940c-922e318582c9.webp',7),(11,'images/product_pic/canned-tuna-in-vegetable-oil/gallery/28d02298-b6df-4827-a3ff-0b9ee0bedc9f.webp',8);
/*!40000 ALTER TABLE `products_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_product`
--

DROP TABLE IF EXISTS `products_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `summery_description` longtext,
  `description` longtext,
  `image` varchar(100) DEFAULT NULL,
  `price` int unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `register_date` datetime(6) NOT NULL,
  `publish_date` datetime(6) NOT NULL,
  `update_date` datetime(6) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `brand_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_product_brand_id_3e2e8fd1_fk_products_brand_id` (`brand_id`),
  KEY `products_product_slug_70d3148d` (`slug`),
  CONSTRAINT `products_product_brand_id_3e2e8fd1_fk_products_brand_id` FOREIGN KEY (`brand_id`) REFERENCES `products_brand` (`id`),
  CONSTRAINT `products_product_chk_1` CHECK ((`price` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_product`
--

LOCK TABLES `products_product` WRITE;
/*!40000 ALTER TABLE `products_product` DISABLE KEYS */;
INSERT INTO `products_product` VALUES (1,'شیر کم چرب مدت دار هراز','','','images/product_pic/milk-low-fat-haraz/af2702ed-d1b0-40b1-bca7-a75a099eb6f1.webp',519000,1,'2025-08-14 03:57:32.743806','2025-08-14 03:53:28.000000','2025-08-14 03:57:32.743806','milk-low-fat-haraz',1),(2,'شیر پرچرب مدت دار هراز','','','images/product_pic/high-fat-haraz/4878d0f0-37b0-4cbe-b489-8aad3d39b443.webp',16900,1,'2025-08-14 04:02:05.506064','2025-08-14 03:58:05.000000','2025-08-14 04:02:05.506064','high-fat-haraz',1),(3,'نوشابه کوکاکولا','','','images/product_pic/cola-cocacola/39751ba3-40d9-48c7-bf1e-9559b36d429e.webp',57540,1,'2025-08-14 04:05:47.125200','2025-08-14 04:02:12.000000','2025-08-14 04:05:47.125200','cola-cocacola',6),(4,'بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله','بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله','بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله بسته ۳ عددی پنیر تاپینگ پیتزا کم چرب رنده شده کاله','images/product_pic/pizza-topping-cheese/96b4dd31-e9de-4256-a492-152ca80aa12a.webp',411810,1,'2025-08-14 12:18:25.391407','2025-08-14 12:15:23.000000','2025-08-14 12:18:25.391407','pizza-topping-cheese',2),(5,'پنیر خامه ای پرچرب ویلی کاله','پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله پنیر خامه ای پرچرب ویلی کاله','پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله  پنیر خامه ای پرچرب ویلی کاله','images/product_pic/full-fat-cream-cheese/688aad9a-225b-44ea-a604-3f685cc13646.webp',79500,1,'2025-08-14 12:21:26.524668','2025-08-14 12:18:53.000000','2025-08-14 12:21:26.524668','full-fat-cream-cheese',2),(6,'پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه','پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه','پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه پنیر سفید نیم چرب حاوی ویتامین D۳ پگاه','images/product_pic/white-cheese-containing-vitamin-D3/6b8df4ca-ea37-468c-8853-b1b615d506fc.webp',77500,1,'2025-08-14 12:24:20.869356','2025-08-14 12:21:35.000000','2025-08-14 12:24:20.869356','white-cheese-containing-vitamin-D3',4),(7,'خامه نیم چرب هراز','خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز','خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز خامه نیم چرب هراز','images/product_pic/semi-fat-cream/b7da3134-e571-47a0-926a-3369eefe3705.webp',55900,1,'2025-08-14 17:59:38.346589','2025-08-14 17:56:52.000000','2025-08-14 17:59:38.346589','semi-fat-cream',1),(8,'کنسرو ماهی تون در روغن گیاهی خوشبخت','کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت','کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت کنسرو ماهی تون در روغن گیاهی خوشبخت','images/product_pic/canned-tuna-in-vegetable-oil/6152abc8-8e99-48f7-b8c0-b4d27ea6b25f.webp',108000,1,'2025-08-14 18:05:12.457607','2025-08-14 17:59:42.000000','2025-08-14 18:05:12.457607','canned-tuna-in-vegetable-oil',7);
/*!40000 ALTER TABLE `products_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_product_group`
--

DROP TABLE IF EXISTS `products_product_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_product_group` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `description` longtext,
  `is_active` tinyint(1) NOT NULL,
  `register_date` datetime(6) NOT NULL,
  `publish_date` datetime(6) NOT NULL,
  `update_date` datetime(6) NOT NULL,
  `slug` varchar(200) DEFAULT NULL,
  `group_parent_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`),
  KEY `products_product_gro_group_parent_id_50b3e273_fk_products_` (`group_parent_id`),
  KEY `products_product_group_slug_a1512bb0` (`slug`),
  CONSTRAINT `products_product_gro_group_parent_id_50b3e273_fk_products_` FOREIGN KEY (`group_parent_id`) REFERENCES `products_product_group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_product_group`
--

LOCK TABLES `products_product_group` WRITE;
/*!40000 ALTER TABLE `products_product_group` DISABLE KEYS */;
INSERT INTO `products_product_group` VALUES (1,'لبنیات','','',1,'2025-08-14 03:48:45.701752','2025-08-14 03:45:46.000000','2025-08-14 03:48:45.701752','dairy-product',NULL),(2,'شیر','images/product_group_pic/شیر/40ab7e45-883e-43fe-a9c6-47258d444362.png','',1,'2025-08-14 03:48:45.702753','2025-08-14 03:45:46.000000','2025-08-14 17:24:37.993249','milk',1),(3,'پنیر','images/product_group_pic/پنیر/c5d48b77-26de-4de0-8ce8-e2a18b3d3bd5.png','',1,'2025-08-14 03:48:45.703752','2025-08-14 03:45:46.000000','2025-08-14 17:22:22.517208','cheese',1),(4,'خامه','images/product_group_pic/خامه/b0000b1f-0828-4c54-a9af-e77a2bd7e2ff.jpg','',1,'2025-08-14 03:48:45.704751','2025-08-14 03:45:46.000000','2025-08-14 17:23:57.822245','cream',1),(5,'نوشیدنی','','',1,'2025-08-14 03:50:52.172094','2025-08-14 03:48:59.000000','2025-08-14 03:50:52.172094','drinks',NULL),(6,'نوشابه','images/product_group_pic/نوشابه/f68b820c-30d4-4e6f-83bd-17263bd36b5b.jpg','',1,'2025-08-14 03:50:52.172094','2025-08-14 03:48:59.000000','2025-08-14 17:26:14.448247','soft-drink',5),(7,'آبمیوه','images/product_group_pic/آبمیوه/bd4dda99-a350-46ab-8f5a-f8fc9762fb39.jpg','',1,'2025-08-14 03:50:52.172094','2025-08-14 03:48:59.000000','2025-08-14 17:25:35.597210','juice',5),(8,'کنسرو و غذای آماده','','',1,'2025-08-14 12:09:26.214902','2025-08-14 12:07:13.000000','2025-08-14 12:09:26.214902','canned-food',NULL),(9,'تن ماهی','images/product_group_pic/تن ماهی/cb25239b-81c3-4d7c-99b8-99dba37e2095.jpg','',1,'2025-08-14 12:09:26.215901','2025-08-14 12:07:14.000000','2025-08-14 17:26:48.941507','tuna-fish',8),(10,'کنسرو و کمپوت','images/product_group_pic/کنسرو و کمپوت/300a55a5-2de7-4f89-bb11-ee4a8ac5920d.jpg','',1,'2025-08-14 12:09:26.216902','2025-08-14 12:07:14.000000','2025-08-14 17:27:31.390166','compote',8),(11,'صبحانه','','',1,'2025-08-14 12:12:30.066974','2025-08-14 12:10:23.000000','2025-08-14 12:12:30.066974','breakfast',NULL),(12,'عسل','images/product_group_pic/عسل/dbf22cd8-4a57-455a-a0ab-7b3ea36dcee9.jpg','',1,'2025-08-14 12:12:30.068065','2025-08-14 12:10:23.000000','2025-08-14 17:28:18.865953','honey',11),(13,'مربا','images/product_group_pic/مربا/bc3f3e1f-bf42-476d-b4c3-de6bc7c2d8d8.jpg','',1,'2025-08-14 12:12:30.069065','2025-08-14 12:10:23.000000','2025-08-14 17:28:42.167665','jam',11),(14,'شکلات صبحانه','images/product_group_pic/شکلات صبحانه/cf432155-b740-4934-97ab-091f54b0ffac.jpg','',1,'2025-08-14 12:12:30.070065','2025-08-14 12:10:23.000000','2025-08-14 17:27:51.756639','breakfast-chocolate',11),(15,'چاشنی و افزودنی','','',1,'2025-08-14 12:14:28.803371','2025-08-14 12:13:17.000000','2025-08-14 12:14:28.803371','condiment',NULL),(16,'سس','images/product_group_pic/سس/f4cda2af-ab85-4aac-9840-5d0e98a7d18a.jpg','',1,'2025-08-14 12:14:28.804370','2025-08-14 12:13:17.000000','2025-08-14 17:29:37.394922','sauce',15),(17,'ادویه','images/product_group_pic/ادویه/d3f28c7c-cd7a-4db7-b794-a363a675d0fb.jpg','',1,'2025-08-14 12:14:28.805371','2025-08-14 12:13:17.000000','2025-08-14 17:29:09.832520','spice',15);
/*!40000 ALTER TABLE `products_product_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_product_product_group`
--

DROP TABLE IF EXISTS `products_product_product_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_product_product_group` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_id` bigint NOT NULL,
  `product_group_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_product_product_product_id_product_group_225bf686_uniq` (`product_id`,`product_group_id`),
  KEY `products_product_pro_product_group_id_d0d7d09a_fk_products_` (`product_group_id`),
  CONSTRAINT `products_product_pro_product_group_id_d0d7d09a_fk_products_` FOREIGN KEY (`product_group_id`) REFERENCES `products_product_group` (`id`),
  CONSTRAINT `products_product_pro_product_id_ddcf34ff_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_product_product_group`
--

LOCK TABLES `products_product_product_group` WRITE;
/*!40000 ALTER TABLE `products_product_product_group` DISABLE KEYS */;
INSERT INTO `products_product_product_group` VALUES (1,1,2),(2,2,2),(3,3,6),(4,4,3),(5,5,3),(6,6,3),(7,7,4),(8,8,9);
/*!40000 ALTER TABLE `products_product_product_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_productfeature`
--

DROP TABLE IF EXISTS `products_productfeature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_productfeature` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `value` varchar(100) DEFAULT NULL,
  `feature_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_productfeat_feature_id_19139ad6_fk_products_` (`feature_id`),
  KEY `products_productfeat_product_id_b0721d47_fk_products_` (`product_id`),
  CONSTRAINT `products_productfeat_feature_id_19139ad6_fk_products_` FOREIGN KEY (`feature_id`) REFERENCES `products_feature` (`id`),
  CONSTRAINT `products_productfeat_product_id_b0721d47_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_productfeature`
--

LOCK TABLES `products_productfeature` WRITE;
/*!40000 ALTER TABLE `products_productfeature` DISABLE KEYS */;
INSERT INTO `products_productfeature` VALUES (1,'1 لیتر',2,1),(2,'200 میلی لیتر',2,2),(3,'1.5 لیتر',2,3),(4,'500 گرم',1,4),(5,'200 گرم',1,5),(6,'400 گرم',1,6),(7,'200 میلی‌لیتر',2,7),(8,'180گرمی',1,8);
/*!40000 ALTER TABLE `products_productfeature` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-20  1:05:11
